<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $id_barang = $_POST["id_barang"];
  $nama_barang = $_POST["nama_barang"];
  $stok = $_POST["stok"];
  $harga_beli = $_POST["harga_beli"];
  $harga_jual = $_POST["harga_jual"];

  $sql = "INSERT INTO tb_barang (id_barang, nama_barang, stok, harga_beli, harga_jual) VALUES ('$id_barang', '$nama_barang', '$stok', '$harga_beli', '$harga_jual')";

  if (mysqli_query($koneksi, $sql)) {
    echo "Data berhasil ditambahkan";
    header("Location: view_data.php"); // Redirect ke halaman view_data setelah menambahkan data
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Tambah Data Barang</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-image: url(bg.jpg);
      background-size: cover;
    }

    h1 {
      text-align: center;
      color: #fff;
      margin-bottom: 40px;
    }

    form {
      background-color: #ccc;
      padding: 30px;
      border-radius: 20px;
      box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.3);
      width: 400px;
      margin: 0 auto;
    }

    input[type="text"],
    input[type="number"] {
      width: 95%;
      padding: 10px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    input[type="submit"] {
      background-color: #007bff;
      color: #fff;
      padding: 10px 15px;
      margin-top: 10px;
      border: none;
      border-radius: 5px;
      border: none;  cursor: pointer;
    }

    input[type="submit"]:hover {
      background-color: lightblue;
    }
  </style>
</head>
<body>
  <h1>Tambah Data Barang</h1>
  <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    Id: <input type="number" name="id_barang"><br>
    Nama Barang: <input type="text" name="nama_barang"><br>
    Stok: <input type="number" name="stok"><br>
    Harga Beli: <input type="number" name="harga_beli"><br>
    Harga Jual: <input type="number" name="harga_jual"><br>
    <input type="submit" value="Submit">
  </form>
</body>
</html>