<?php
include 'koneksi.php';

$sql = "SELECT * FROM tb_barang";
$result = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html>
<head>
<title>Data Barang</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <h1>Data Barang</h1>
  <table>
    <tr>
      <th>ID</th>
      <th>Nama Barang</th>
      <th>Stok</th>
      <th>Harga Beli</th>
      <th>Harga Jual</th>
      <th>Aksi</th>
    </tr>
    <?php
    while($row = mysqli_fetch_assoc($result)) {
      echo "<tr>";
      echo "<td>" . $row["id_barang"] . "</td>";
      echo "<td>" . $row["nama_barang"] . "</td>";
      echo "<td>" . $row["stok"] . "</td>";
      echo "<td>" . $row["harga_beli"] . "</td>";
      echo "<td>" . $row["harga_jual"] . "</td>";
      echo "<td><a href='edit.php?id=" . $row["id_barang"] . "'>Edit</a> | <a href='proses_data.php?id=" . $row["id_barang"] . "&aksi=hapus'>Hapus</a></td>";
      echo "</tr>";
    }
    ?>
  </table>
</body>
</html>