<?php
include 'koneksi.php';

$id = $_GET["id"];

$sql = "SELECT * FROM tb_barang WHERE id_barang = $id";
$result = mysqli_query($koneksi, $sql);
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Edit Data Barang</title>
  <style>
      body {
        font-family: Arial, sans-serif;
        background-image: url(bg.jpg);
        background-size: cover;
      }

      h1 {
        text-align: center;
        color: #fff;
        margin-bottom: 40px;
      }

      form {
        background-color: #ccc;
        padding: 30px;
        border-radius: 20px;
        box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.3);
        width: 400px;
        margin: 0 auto;
      }

      input[type="text"],
      input[type="number"] {
        width: 95%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
      }

      input[type="submit"] {
        background-color: #007bff;
        color: #fff;
        padding: 10px 15px;
        margin-top: 10px;
        border: none;
        border-radius: 5px;
        border: none;  cursor: pointer;
      }

      input[type="submit"]:hover {
        background-color: lightblue;
      }
  </style>
</head>
<body>
  <h1>Edit Data Barang</h1>
  <form method="post" action="proses_data.php?id=<?php echo $id; ?>&aksi=edit">
    Nama Barang: <input type="text" name="nama_barang" value="<?php echo $row["nama_barang"]; ?>"><br>
    Stok: <input type="number" name="stok" value="<?php echo $row["stok"]; ?>"><br>
    Harga Beli: <input type="number" name="harga_beli" value="<?php echo $row["harga_beli"]; ?>"><br>
    Harga Jual: <input type="number" name="harga_jual" value="<?php echo $row["harga_jual"]; ?>"><br>
    <input type="submit" value="Submit">
  </form>
</body>
</html>