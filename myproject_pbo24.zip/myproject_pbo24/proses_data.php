<?php
include 'koneksi.php';

$id = $_GET["id"];
$aksi = $_GET["aksi"];

if ($aksi == "hapus") {
  $sql = "DELETE FROM tb_barang WHERE id_barang = $id";
  if (mysqli_query($koneksi, $sql)) {
    header("Location: view_data.php");
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
  }
} else if ($aksi == "edit") {
  $id_barang = $_POST["id_barang"];
  $nama_barang = $_POST["nama_barang"];
  $stok = $_POST["stok"];
  $harga_beli = $_POST["harga_beli"];
  $harga_jual = $_POST["harga_jual"];

  $sql = "UPDATE tb_barang SET nama_barang='$nama_barang', stok='$stok', harga_beli='$harga_beli', harga_jual='$harga_jual' WHERE id_barang=$id";

  if (mysqli_query($koneksi, $sql)) {
    header("Location: view_data.php");
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
  }
}
?>