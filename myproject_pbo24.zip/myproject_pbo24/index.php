<!DOCTYPE html>
<html>
<head>
  <title>Aplikasi Bisnis Saya</title>
  <style>
      body {
        font-family: Arial, sans-serif;
        background-image: url(bg.jpg);
        background-size: cover;
        text-align: center;
        margin: 20px;
      }

      h1 {
        color: white;
        margin-bottom: 40px;
      }
        
      a {
        text-decoration: none;
        color: white;
        padding: 6px 24px;
        border: 2px solid #fff;
        background: transparent;
        border-radius: 6px;
        cursor: pointer;
      }

      a:hover {
        background-color: lightblue;
      }
  </style>
</head>
<body>
  <h1>Selamat Datang Di Aplikasi Bisnis Saya</h1>
  <a href="add_data.php">Tambah Data</a>
  <a href="view_data.php">Lihat Data</a>
</body>
</html> 